# Simulated BCR lineages

Each folder contains multiple BCR lineage tree corresponding fasta files, containg at most the same number of sequences as the folder name.
For each given lineage file , "tree.fasta", there is the true tree "tree.naive.nk" and the inferred one by ClonalTree "tree.clonalTree.nk".